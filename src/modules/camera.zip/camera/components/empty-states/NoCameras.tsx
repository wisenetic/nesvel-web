import { Video } from "lucide-react";

import { Button } from "@/core/components/ui/button";

type NoCamerasProps = {
  onAdd?: () => void;
};

export default function NoCameras({ onAdd }: NoCamerasProps) {
  return (
    <div className="border rounded-xl py-16 flex flex-col items-center justify-center text-center bg-card/30">
      <Video className="mb-3 h-8 w-8 text-muted-foreground" />
      <div className="mb-1 text-base font-medium">No cameras configured</div>
      <div className="mb-4 text-sm text-muted-foreground">
        Add your first camera to start monitoring
      </div>
      <Button size="sm" onClick={onAdd}>
        + Add Camera
      </Button>
    </div>
  );
}
