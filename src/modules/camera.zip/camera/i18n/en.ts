export default {
  camera: {
    title: "Cameras",
    list_title: "Cameras",
    list_description: "Manage IP cameras and RTSP streams",
    add_button: "Add Camera",
    edit_button: "Edit Camera",
    delete_confirm: "Are you sure you want to delete this camera?",
  },
};
