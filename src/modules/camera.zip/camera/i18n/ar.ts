export default {
  camera: {
    title: "الكاميرات",
    list_title: "الكاميرات",
    list_description: "إدارة كاميرات IP وتدفقات RTSP",
    add_button: "إضافة كاميرا",
    edit_button: "تعديل الكاميرا",
    delete_confirm: "هل أنت متأكد أنك تريد حذف هذه الكاميرا؟",
  },
};
